package com.example.android_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ThreePlayerGameActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_three_player_game);
    }
}
